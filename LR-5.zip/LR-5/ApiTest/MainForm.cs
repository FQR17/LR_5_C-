﻿using System;
using System.Net;
using System.Text;
using System.Windows.Forms;
using Newtonsoft.Json.Linq;

namespace ApiTest
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
        }

        private void BtnAuthClick(object sender, EventArgs e)
        {
            string token = null;

            using (AuthForm authForm = new AuthForm())
            {
                if (authForm.ShowDialog() == DialogResult.Yes) token = authForm.Token;
            }

            if (string.IsNullOrEmpty(token))
            {
                MessageBox.Show("Ошибка авторизации", "Ошибка",
                                MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // Методы API см. в документации https://vk.com/dev/methods

            var client = new WebClient {Encoding = Encoding.UTF8};
            string json = client.DownloadString($"https://api.vk.com/method/{tbMethod.Text}?{tbParams.Text}&access_token={token}&v=5.126");

            JObject jsonObject = JObject.Parse(json);
            tbLog.Text = jsonObject.ToString();
        }

        private void tbParams_TextChanged(object sender, EventArgs e)
        {

        }

        private void exitprog(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void webBrowser1_DocumentCompleted(object sender, WebBrowserDocumentCompletedEventArgs e)
        {

        }

        private void tbLog_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
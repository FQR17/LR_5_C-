﻿using System;
using System.Linq;
using System.Windows.Forms;

namespace ApiTest
{
    /// <summary>
    /// Форма авторизации API VK содержит визуальный компонент веб-браузер на основе движка IE или Edge,
    /// используемый для отображения страницы ввода логина-пароля от VK по заданному URI
    /// https://vk.com/dev/implicit_flow_user
    /// </summary>
    public partial class AuthForm : Form
    {
        private string _authorizeUri = "https://oauth.vk.com/authorize";
        private string _redirectUri = "https://oauth.vk.com/blank.html";

        // Необходимо зарегистрировать свое приложение на https://vk.com/apps?act=manage
        // Затем получить ID приложения и записать его в переменную _clientId:

        private int _clientId = 6928665;

        public string Token { get; private set; }

        public AuthForm()
        {
            InitializeComponent();
        }

        private void AuthFormShown(object sender, EventArgs e)
        {
            // Отображение на форме в браузере страницы авторизации _authorizeUri
            // После успешного входа происходит редирект на _redirectUri

            webBrowser.Navigate(
                new Uri("https://oauth.vk.com/authorize?"
                        + $"client_id={_clientId}&display=page&redirect_uri={_redirectUri}&"
                        + "response_type=token&v=5.126&state=123456"));
        }

        private void WebBrowserNavigated(object sender, WebBrowserNavigatedEventArgs e)
        {
            // Отлавливаем редирект в этом обработчике собития Navigated браузера
            // В итоге получаем токен, который в дальнейшем нужно передавать для доступа к API

            string uri = e.Url.ToString();
            if (uri.StartsWith(_authorizeUri)) return;

            if (!uri.StartsWith(_redirectUri))
            {
                DialogResult = DialogResult.No;
                return;
            }

            var parameters = (from param in uri.Split('#')[1].Split('&')
                              let parts = param.Split('=')
                              select new
                                  {
                                      Name = parts[0],
                                      Value = parts[1]
                                  }
                             ).ToDictionary(v => v.Name, v => v.Value);

            Token = parameters["access_token"];
            DialogResult = DialogResult.Yes;
        }
    }
}